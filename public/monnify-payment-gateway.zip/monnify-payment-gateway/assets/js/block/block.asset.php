<?php return array('dependencies' => array('react', 'wp-html-entities'), 'version' => 'bbd76324e653310473bb');
